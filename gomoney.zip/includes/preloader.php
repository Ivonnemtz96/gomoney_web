<div class="offwrap"></div>

<!--Preloader start here-->
<div id="pre-load">
    <div id="loader" class="loader">
        <div class="loader-container">
            <div class="loader-icon"><img src="assets/images/fav.png" alt="Solvency - Credit Repair & Finance Html Template "></div>
        </div>
    </div>
</div>
<!--Preloader area end here-->


