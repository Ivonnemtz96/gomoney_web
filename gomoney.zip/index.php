<!DOCTYPE html>
<html lang="en">
<?
include('includes/head.php');
?>
<body class="defult-home">
    <?
        include('includes/preloader.php');
    ?>
    <div class="main-content">
        <?
        include('includes/header.php');
        include('modules/index.php');
        include('modules/contacto.php');
        ?>
    </div>   
    <?
        include('includes/footer.php');
        include('includes/scripts.php');
    ?>
</body>
</html>